package EmployeeSalary;

import java.util.Scanner;

import java.util.Date;

public class EmployeeTest {

    static Scanner in = new Scanner(System.in);

    public static void main(String args[]) {
        Employee employee = new Employee();
        EmployeeInput input = new EmployeeInput();
        String[] options = {"HOURLY", "PIECEWORKER", "COMMISSION", "BASEPLUSCOMMISSION", "EXIT"};
        int choice = 0;
        int id = 143;
        System.out.println("......EMPLOYEE DETAILS......");
        MyName name = new MyName(input.getFname(), input.getMname(), input.getLname());
        Employee emp = new Employee(id, name, new Date());
        do {
            System.out.println(">>>>>>>>>>>><<<<<<<<<<<<");
            System.out.println(".....EMPLOYEE TYPE.......");
            for (int i = 0; i < options.length; ++i) {
                System.out.printf("[%d.] %s\n", i + 1, options[i]);

            }
            do {

                System.out.print("Enter your choice: ");
                choice = in.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("..............................");
                        System.out.println(".....HOURLY EMPLOYEE......");
                        emp.displayInfo();
                        HourlyEmployee hrly = new HourlyEmployee(id, name, new Date(), input.ratePerHour(), input.hoursWorked());
                        hrly.displayHourLyEmpInfo();
                        break;
                    case 2:
                        System.out.println("..................................");
                        System.out.println(".....PIECE WORKER EMPLOYEE.....");
                        PieceWorkerEmployee piece = new PieceWorkerEmployee(id, name, new Date(), input.totalPiecesFinished(), input.ratePerPiece());
                        piece.displayPieceWorkerSalaryDetails();
                        break;
                    case 3:
                        System.out.println(".................................");
                        System.out.println(".....COMMISSION EMPLOYEE......");
                        CommissionEmployee commission = new CommissionEmployee(id, name, new Date(), input.totalSales());
                        commission.displayComEmpDetails();
                        break;
                    case 4:
                        System.out.println("..........................................."
                                + "");
                        System.out.println(".....BASE PLUS COMMISSION EMPLOYEE.....");
                        BasePlusCommisionEmployee base = new BasePlusCommisionEmployee(id, name, new Date(), input.totalSales(), input.baseSalary());
                        base.displayBaseComEmployeeDetails();
                        break;
                    case 5:
                        System.out.println("........................................");
                        System.out.println("Thank You For Using Our Program!\n Smile Before You Leave!");
                        break;

                    default:
                        System.out.println("Invalid Choice!");
                }

            } while (!(choice >= 1 && choice <= 5));

        } while (choice != 5);

    }

}
