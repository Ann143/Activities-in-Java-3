
package BitayBata;

public class Test {
    static Bitay name = new Bitay();
    
    public static void main(String[] args) {
        
        name.welcome();

    }
    
}
